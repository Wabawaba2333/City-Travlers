<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="图块" tilewidth="400" tileheight="223" tilecount="18" columns="0">
 <grid orientation="orthogonal" width="1" height="1"/>
 <tile id="0">
  <image width="155" height="55" source="../png/图块/frame1.png"/>
 </tile>
 <tile id="1">
  <image width="65" height="96" source="../png/图块/noteboard1.png"/>
 </tile>
 <tile id="2">
  <image width="140" height="187" source="../png/图块/pic1.png"/>
 </tile>
 <tile id="3">
  <image width="98" height="134" source="../png/图块/pic2.png"/>
 </tile>
 <tile id="4">
  <image width="71" height="98" source="../png/图块/pic3.png"/>
 </tile>
 <tile id="5">
  <image width="46" height="67" source="../png/图块/pic4.png"/>
 </tile>
 <tile id="6">
  <image width="56" height="65" source="../png/图块/plant1.png"/>
 </tile>
 <tile id="7">
  <image width="158" height="169" source="../png/图块/table1.png"/>
 </tile>
 <tile id="8">
  <image width="233" height="131" source="../png/图块/carpet1.png"/>
 </tile>
 <tile id="9">
  <image width="137" height="98" source="../png/图块/carpet2.png"/>
 </tile>
 <tile id="10">
  <image width="113" height="176" source="../png/图块/chair1.png"/>
 </tile>
 <tile id="11">
  <image width="400" height="223" source="../png/图块/counter1.png"/>
 </tile>
 <tile id="12">
  <image width="54" height="96" source="../png/plant/plant5.png"/>
 </tile>
 <tile id="13">
  <image width="83" height="95" source="../png/plant/plant1.png"/>
 </tile>
 <tile id="14">
  <image width="65" height="96" source="../png/plant/plant2.png"/>
 </tile>
 <tile id="15">
  <image width="64" height="97" source="../png/plant/plant3.png"/>
 </tile>
 <tile id="16">
  <image width="91" height="142" source="../png/plant/plant4.png"/>
 </tile>
 <tile id="17">
  <image width="241" height="59" source="../png/开关门动画/door1.png"/>
 </tile>
</tileset>

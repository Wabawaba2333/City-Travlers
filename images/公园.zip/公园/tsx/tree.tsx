<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="tree" tilewidth="752" tileheight="624" tilecount="13" columns="0">
 <grid orientation="orthogonal" width="1" height="1"/>
 <tile id="0">
  <image width="144" height="192" source="../png/tree/f4.png"/>
 </tile>
 <tile id="1">
  <image width="672" height="619" source="../png/tree/gravewatcher.png"/>
 </tile>
 <tile id="2">
  <image width="352" height="480" source="../png/tree/t1.png"/>
 </tile>
 <tile id="3">
  <image width="368" height="464" source="../png/tree/t2.png"/>
 </tile>
 <tile id="4">
  <image width="752" height="624" source="../png/tree/t3.png"/>
 </tile>
 <tile id="5">
  <image width="400" height="624" source="../png/tree/t4.png"/>
 </tile>
 <tile id="6">
  <image width="384" height="560" source="../png/tree/t5.png"/>
 </tile>
 <tile id="7">
  <image width="144" height="192" source="../png/tree/f1.png"/>
 </tile>
 <tile id="8">
  <image width="112" height="160" source="../png/tree/f2.png"/>
 </tile>
 <tile id="9">
  <image width="96" height="144" source="../png/tree/f3.png"/>
 </tile>
 <tile id="10">
  <image width="158" height="176" source="../png/tree/notice2.png"/>
 </tile>
 <tile id="11">
  <image width="144" height="176" source="../png/tree/notice3.png"/>
 </tile>
 <tile id="12">
  <image width="137" height="160" source="../png/tree/notice.png"/>
 </tile>
</tileset>

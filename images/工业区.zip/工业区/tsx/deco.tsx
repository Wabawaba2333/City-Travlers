<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="deco" tilewidth="752" tileheight="624" tilecount="41" columns="0">
 <grid orientation="orthogonal" width="1" height="1"/>
 <tile id="0">
  <image width="222" height="131" source="../png/deco/flower2.png"/>
 </tile>
 <tile id="1">
  <image width="130" height="104" source="../png/deco/flower3.png"/>
 </tile>
 <tile id="2">
  <image width="67" height="479" source="../png/deco/lamp.png"/>
 </tile>
 <tile id="3">
  <image width="352" height="480" source="../png/deco/t1.png"/>
 </tile>
 <tile id="4">
  <image width="368" height="464" source="../png/deco/t2.png"/>
 </tile>
 <tile id="5">
  <image width="752" height="624" source="../png/deco/t3.png"/>
 </tile>
 <tile id="6">
  <image width="400" height="624" source="../png/deco/t4.png"/>
 </tile>
 <tile id="7">
  <image width="384" height="560" source="../png/deco/t5.png"/>
 </tile>
 <tile id="8">
  <image width="119" height="162" source="../png/deco/1.png"/>
 </tile>
 <tile id="9">
  <image width="96" height="112" source="../png/deco/2.png"/>
 </tile>
 <tile id="10">
  <image width="112" height="160" source="../png/deco/3.png"/>
 </tile>
 <tile id="11">
  <image width="64" height="80" source="../png/deco/4.png"/>
 </tile>
 <tile id="12">
  <image width="64" height="80" source="../png/deco/5.png"/>
 </tile>
 <tile id="13">
  <image width="288" height="224" source="../png/deco/6.png"/>
 </tile>
 <tile id="14">
  <image width="288" height="208" source="../png/deco/7.png"/>
 </tile>
 <tile id="15">
  <image width="155" height="208" source="../png/deco/8.png"/>
 </tile>
 <tile id="16">
  <image width="155" height="183" source="../png/deco/9.png"/>
 </tile>
 <tile id="17">
  <image width="85" height="56" source="../png/deco/10.png"/>
 </tile>
 <tile id="18">
  <image width="96" height="80" source="../png/deco/11.png"/>
 </tile>
 <tile id="19">
  <image width="144" height="64" source="../png/deco/12.png"/>
 </tile>
 <tile id="20">
  <image width="114" height="141" source="../png/deco/board1.png"/>
 </tile>
 <tile id="21">
  <image width="240" height="144" source="../png/deco/chair.png"/>
 </tile>
 <tile id="22">
  <image width="192" height="208" source="../png/deco/f1.png"/>
 </tile>
 <tile id="23">
  <image width="224" height="192" source="../png/deco/f2.png"/>
 </tile>
 <tile id="24">
  <image width="240" height="256" source="../png/deco/f3.png"/>
 </tile>
 <tile id="25">
  <image width="183" height="499" source="../png/deco/f4.png"/>
 </tile>
 <tile id="26">
  <image width="93" height="112" source="../png/deco/flower1.png"/>
 </tile>
 <tile id="27">
  <image width="368" height="464" source="../../公园/png/tree/t2.png"/>
 </tile>
 <tile id="28">
  <image width="752" height="624" source="../../公园/png/tree/t3.png"/>
 </tile>
 <tile id="29">
  <image width="400" height="624" source="../../公园/png/tree/t4.png"/>
 </tile>
 <tile id="30">
  <image width="384" height="560" source="../../公园/png/tree/t5.png"/>
 </tile>
 <tile id="31">
  <image width="352" height="480" source="../../公园/png/tree/t1.png"/>
 </tile>
 <tile id="32">
  <image width="306" height="422" source="../png/deco/brige.png"/>
 </tile>
 <tile id="33">
  <image width="95" height="128" source="../png/deco/walldeco4.png"/>
 </tile>
 <tile id="34">
  <image width="176" height="159" source="../png/deco/walldeco1.png"/>
 </tile>
 <tile id="35">
  <image width="96" height="80" source="../png/deco/walldeco2.png"/>
 </tile>
 <tile id="36">
  <image width="152" height="160" source="../png/deco/walldeco3.png"/>
 </tile>
 <tile id="37">
  <image width="192" height="80" source="../png/deco/stone1.png"/>
 </tile>
 <tile id="38">
  <image width="128" height="48" source="../png/deco/stone2.png"/>
 </tile>
 <tile id="39">
  <image width="176" height="80" source="../png/deco/stone3.png"/>
 </tile>
 <tile id="40">
  <image width="129" height="528" source="../png/deco/lanp2.png"/>
 </tile>
</tileset>
